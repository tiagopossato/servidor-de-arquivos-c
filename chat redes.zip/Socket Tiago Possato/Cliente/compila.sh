#!/bin/bash

gcc main.c -o cliente -lpthread
chmod +x cliente

touch executar[em_terminal].sh
chmod +x executar[em_terminal].sh

echo ./cliente >> executar[em_terminal].sh

