/* 
 * File:   codigos.h
 * Author: tiago
 *
 * Created on 1 de Maio de 2016, 16:01
 * 
 * Arquivo com os códigos utilizados na comunicação
 */

#ifndef CODIGOS_H
#define	CODIGOS_H

#ifdef	__cplusplus
extern "C" {
#endif
    /*************CODIGOS DO CLIENTE*************
     * Codigos do cliente são valores válidos 
     * entre 1 e 49
     */
#define CLI_MEU_NOME    1
#define CLI_ALTERAR_NOME    2
#define CLI_GET_CLIENTES    3
#define CLI_SEND_MSG    4
#define CLI_SEND_BROADCAST  5
#define CLI_SET_STATUS  6

#define CLI_ONLINE  20
#define CLI_OCUPADO 21
#define CLI_DESCONECTADO 22

    /*************CODIGOS DO SERVIDOR*************
     * Codigos do servidor são valores válidos 
     * entre 59 e 99
     */

#ifdef	__cplusplus
}
#endif

#endif	/* CODIGOS_H */

