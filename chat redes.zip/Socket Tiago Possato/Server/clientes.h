/* 
 * File:   clientes.h
 * Author: tiago
 *
 * Created on 30 de Abril de 2016, 23:26
 * 
 * Define as estruturas e funções para controlar os clientes conectados no servidor
 */

#ifndef CLIENTES_H
#define	CLIENTES_H

#include <stdbool.h>

#ifdef	__cplusplus
extern "C" {
#endif

    /*
     * Estrura Cliente
     * Armazena cada cliente conectado no servidor
     */
    struct Cliente {
        unsigned int id; //identificador único
        char ip[16]; //ip do cliente
        char nome[128]; //Nome do cliente
        int socket;//identificador do socket do cliente
        int status; //status do cliente
        struct Cliente *prox; //ponteiro para o próximo cliente, utilizado na lista encadeada
    };
    typedef struct Cliente cliente;

    typedef struct lClientes {
        cliente *head;
        int quantidade;
    } listaClientes;

    listaClientes *CLIENTES;

    int novoCliente(char *ip, int socket);
    bool apagaCliente(unsigned int id);
    bool setaNome(char *nome, cliente *cli);
    cliente *procuraCliente(unsigned int id);
    cliente *procuraClientePorIP(char *ip);
    void imprimeListaClientes();
#ifdef	__cplusplus
}
#endif

#endif	/* CLIENTES_H */

