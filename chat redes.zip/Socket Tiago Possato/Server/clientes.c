#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "clientes.h"
#include "codigos.h"

int idClientes = 0;

int procuraItem(unsigned int id);
listaClientes *criaListaClientes();
bool insereCliente(cliente *novoCliente);

/**
 * Insere novo cliente na lista
 * @param ip
 * @param socket
 * @return O id do novo cliente
 */
int novoCliente(char *ip, int socket) {
    if (CLIENTES == NULL) {
        CLIENTES = criaListaClientes();
    }
    cliente *novo = (cliente *) malloc(sizeof (cliente));
    strcpy(novo->ip, ip);
    novo->id = ++idClientes;
    sprintf(novo->nome, "Sem nome");
    novo->socket = socket;   
    novo->prox = NULL;
    novo->status = CLI_ONLINE;
    insereCliente(novo);
    return novo->id;
}

/**
 * Seta o nome do cliente
 * @param nome
 * @param cli
 * @return 
 */
bool setaNome(char *nome, cliente *cli) {
    if (cli == NULL) return false;
    strcpy(cli->nome, nome);
    return true;
}

/**
 * Apaga um cliente da lista
 * @param id
 * @return 
 */
bool apagaCliente(unsigned int id) {
    int posicao = procuraItem(id);

    if (posicao == 0)
        return false;
    if (CLIENTES->head == NULL)
        return false;

    int i = 1;

    //cria nova struct e aponta para o primeiro valor da lista
    cliente *anterior = CLIENTES->head,
            //cria nova struct e aponta para o segundo valor
            *proxima = anterior->prox;

    //caso for o primeiro elemento
    if (posicao == 1) {
        CLIENTES->head = proxima;
        //libera memoria
        free(anterior);
    } else {
        //procura a posicao para apagar o elemento
        for (i = 1; i < posicao - 1; i++) {
            //desloca para proxima casa
            proxima = proxima->prox;
            anterior = anterior->prox;
        }
        //aponta para o elemento apontado pelo proximo elemento da lista;
        anterior->prox = proxima->prox;
        //libera memoria
        free(proxima);
    }
    CLIENTES->quantidade--;
    return true;
}

/**
 * Procura um clienta na lista utilizando o ip como parâmetro
 * @param ip
 * @return O cliente procurado ou NULL
 */
cliente *procuraClientePorIP(char *ip) {
    cliente *tmp = CLIENTES->head;
    //Percorre toda a lista
    while (tmp != NULL) {
        if (strcmp(tmp->ip, ip) == 0) {
            return tmp;
        }
        tmp = tmp->prox;
    }
    return NULL;
}

/**
 * Procura por um cliente utilizando como parâmetro o ID
 * @param id
 * @return O cliente procurado ou NULL
 */
cliente *procuraCliente(unsigned int id) {
    cliente *tmp = CLIENTES->head;

    //Percorre toda a lista
    while (tmp != NULL) {
        if (tmp->id == id) {
            return tmp;
        }
        tmp = tmp->prox;
    }
    return NULL;
}

/**
 * Imprime lista de clientes no servidor
 */
void imprimeListaClientes() {
    if (CLIENTES->head == NULL) {
        return;
    }

    cliente *tmp = CLIENTES->head;
    printf("\nCLIENTES:\n");

    while (tmp != NULL) {
        printf("%d : ", tmp->id);
        printf("%s : ", tmp->ip);
        printf("%s : ", tmp->nome);
        printf("%d : ", tmp->status);
        printf("%d \n", tmp->socket);
        tmp = tmp->prox;
    }
}

/****FUNCOES 'PRIVADAS'*****/

/**
 * Cria a lista de clientes
 * @return 
 */
listaClientes *criaListaClientes() {
    listaClientes *lCli;
    lCli = (listaClientes*) malloc(sizeof (listaClientes));
    lCli->head = NULL;
    lCli->quantidade = 0;
    return lCli;
}

/**
 * Insere novo cliente na lista
 * @param novoCliente
 * @return 
 */
bool insereCliente(cliente *novoCliente) {
    //verifica se a lista esta vazia
    if (CLIENTES->head == NULL) {
        //caso estiver, aponta para a estrutura criada
        CLIENTES->head = novoCliente;
    } else {
        //caso nao estiver vazia
        //cria um nó temporario, apontando para o primeiro elemento da lista
        cliente *tmp = CLIENTES->head;
        //percorre a lista ate encontrar o ultimo elemento
        while (tmp->prox != NULL) {
            tmp = tmp->prox;
        }
        //insere o elemento novo no final da lista
        tmp->prox = novoCliente;
    }
    CLIENTES->quantidade++;
    return true;
}

/**
 * Procura um item na lista pelo id
 * @param id
 * @return A posicao na lista
 */
int procuraItem(unsigned int id) {
    char pos = 1;
    cliente *tmp = CLIENTES->head;

    //Percorre toda a lista
    while (tmp != NULL) {
        if (tmp->id == id) {
            return pos;
        }
        pos++;
        tmp = tmp->prox;
    }
    return 0;
}