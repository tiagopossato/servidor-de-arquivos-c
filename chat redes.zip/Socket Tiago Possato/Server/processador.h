/* 
 * File:   digestor.h
 * Author: tiago
 *
 * Created on 1 de Maio de 2016, 15:59
 * 
 * Arquivo com as funções utilizadas para processar as mensagens recebidas
 */

#ifndef PROCESSADOR_H
#define	PROCESSADOR_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include "clientes.h"
    bool processarMensagem(char *mensagem, cliente *cli);
    int extraiCodigo(char *buffer);
    bool encaminhaMensagem(char *mensagem, cliente *cli);
    void enviaListaClientes(cliente *cli);
    bool enviaBroadcast(cliente *cli, char *msg);
#ifdef	__cplusplus
}
#endif

#endif	/* PROCESSADOR_H */

