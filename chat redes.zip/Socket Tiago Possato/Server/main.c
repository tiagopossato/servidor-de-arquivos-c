#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "netinet/in.h"
#include "sys/socket.h"
#include "sys/types.h"
#include "arpa/inet.h"
#include "netinet/in.h"
#include "clientes.h"
#include "processador.h"
#include "codigos.h"

#define ERRO -1
#define TAMMAX 1024 //tamanho maximo da string

/**
 * Thread para controlar a conexão com cada novo cliente conectado no servidor
 * @param id O ID do novo cliente
 * @return 
 */
void *Recebe(void *id) {
    char *msgrecv = malloc(TAMMAX);
    int qtd = 0;
    bzero(msgrecv, strlen(msgrecv));
    cliente *cli = procuraCliente((int) id);

    while (true) {
        qtd = recv(cli->socket, msgrecv, TAMMAX, 0); //recebe os dados no socket
        if (qtd <= 0)//verifica se é para sair
        {
            printf("\nConexão com %s fechada.\n", cli->ip);
            sprintf(msgrecv, "%s SAIU", cli->nome);
            enviaBroadcast(cli, msgrecv);
            close(cli->socket);
            apagaCliente(cli->id);
            break;
        }
        fprintf(stdout, "\nCliente %d: %s", cli->id, msgrecv);
        processarMensagem(msgrecv, cli);
        bzero(msgrecv, strlen(msgrecv));
    }
    free(msgrecv);
    pthread_exit(NULL);
}

void main(int argc, char *argv[]) {
    /*cria a estrutura para o socket local*/
    struct sockaddr_in local, network;
    /*Variavel que armazenará o tamanho da estrutura*/
    socklen_t strucsize;
    int status, resp, sock, newsock;
    /*Quantidade de threads que o servidor irá criar*/
    int num_threads = 256;
    int i = 0;
    /*Vetor que armazenará as threads*/
    pthread_t thread[num_threads];
    int cliente = 0;
    char ip[16];
    int porta;
    /*Abre o arquivo de configurações e pega o IP e a porta*/
    FILE *arq = fopen("config.txt", "r");
    if (arq == NULL) {
        printf("Arquivo de configurações não encontrado!\n");
        return;
    }
    fgets(ip, 16, arq); //le o ip 
    fscanf(arq, "%d", &porta); // le a porta
    fclose(arq); //fecha o arquivo
    /*Cria o socket*/
    sock = socket(PF_INET, SOCK_STREAM, 0);
    /*Verifica se foi criado*/
    if (sock == ERRO) {
        perror("Socket");
        exit(0);
    }
    /*Preenche a estrutura com zeros*/
    bzero((char *) &local, sizeof (local));
    /*Seta os valores da estrutura do socke local*/
    local.sin_family = PF_INET; //Protocolo IP
    local.sin_port = htons(porta); //Porta
    local.sin_addr.s_addr = inet_addr(ip); //IP
    strucsize = sizeof (struct sockaddr_in); //pega o tamanho da estrutura

    /*associa o socket à porta */
    resp = bind(sock, (struct sockaddr *) &local, strucsize);
    if (resp == ERRO) {
        perror("Bind");
        exit(0);
    }

    /*Aguarda conexão do cliente*/
    /* O segundo parametro indica quantas conexões serão colocadas na fila 
     * antes da próxima ser recusada*/
    listen(sock, 10);

    /*loop para o accept*/
    while (1) {
        puts("Aguardando conexão...");
        //Recebe nova conexão
        if ((newsock = accept(sock, (struct sockaddr *) &network, &strucsize)) < 0) {
            perror("accept");
            exit(1);
        } else//caso não deu erro na conexão
        {
            printf("\nRecebendo conexao de: %s\n", inet_ntoa(network.sin_addr));
            /*Cria um novo cliente*/
            cliente = novoCliente(inet_ntoa(network.sin_addr), newsock);
            //cria nova thread passando como parametro o numero do cliente
            status = pthread_create(&thread[i], (void *) NULL, (void*) Recebe, (void *) cliente);
            if (status) {//ocorreu erro
                perror("pthread_create");
                exit(-1);
            }
            i++;
        }
    }

    //esperando término das threads
    for (i = 0; i < num_threads; i++) {
        printf("Aguardando thread numero (id): %d\n", i);
        status = pthread_join(thread[i], NULL);
        if (status) {
            perror("pthread_join");
            exit(-1);
        }
    }
}