#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "processador.h"
#include "codigos.h"

/**
 * Analiza a mensagem recebida e executa a ação correspondente
 * @param mensagem
 * @param cli
 * @return 
 */
bool processarMensagem(char *mensagem, cliente *cli) {
    int codigo;
    char *tmp;
    char *status;
    if (mensagem == NULL) {
        return false;
    }
    codigo = extraiCodigo(mensagem);

    switch (codigo) {
        case CLI_MEU_NOME:
            if (!setaNome(mensagem, cli))
                send(cli->socket, "Erro", strlen("Erro"), 0);

            break;
        case CLI_ALTERAR_NOME:
            if (!setaNome(mensagem, cli))
                send(cli->socket, "Erro", strlen("Erro"), 0);

            break;
        case CLI_GET_CLIENTES:
            //se o ip solicitante for valido
            enviaListaClientes(cli);
            return true;
            break;
        case CLI_SEND_MSG:
            if (!encaminhaMensagem(mensagem, cli))
                send(cli->socket, "USUÁRIO NÃO ENCONTRADO", strlen("USUÁRIO NÃO ENCONTRADO"), 0);

            break;
        case CLI_SEND_BROADCAST:
            tmp = malloc(strlen(mensagem) + 4);
            sprintf(tmp, "[BCAST]%s: %s", cli->nome, mensagem);
            enviaBroadcast(cli, tmp);
            free(tmp);
            break;

        case CLI_SET_STATUS:
            codigo = extraiCodigo(mensagem);
            if (codigo > 0) {
                switch (codigo) {
                    case CLI_ONLINE:
                        cli->status = codigo;
                        status = malloc(strlen("ON-LINE"));
                        sprintf(status, "ON-LINE");
                        break;
                    case CLI_OCUPADO:
                        cli->status = codigo;
                        status = malloc(strlen("OCUPADO"));
                        sprintf(status, "OCUPADO");
                        break;
                    default://codigo desconhecido
                        send(cli->socket, "STATUS NÃO RECONHECIDO", strlen("STATUS NÃO RECONHECIDO"), 0);
                        break;
                }
                tmp = malloc(strlen(cli->nome) + strlen(status) + 10);
                sprintf(tmp, "%s ESTÁ %s", cli->nome, status);
                enviaBroadcast(cli, tmp);
                free(tmp);
                free(status);
            }
            break;
        default:
            send(cli->socket, "CODIGO NÃO RECONHECIDO", strlen("CODIGO NÃO RECONHECIDO"), 0);
            break;
    }
    return false;
}

/**
 * Extrai o código da mensagem e retorna o valor correspondente
 * @param buffer
 * @return O primeiro código encontrado na mensagem ou 0, caso nenhum código 
 * tenha sido identificado
 */
int extraiCodigo(char *buffer) {
    char *tmp = malloc(strlen(buffer));
    char cod[20];
    unsigned char pos = 0;
    while (buffer[pos] >= '0' && buffer[pos] <= '9') {
        pos++;
    }
    strncpy(cod, (const char *) (buffer), pos);
    cod[pos] = '\0';
    if (atoi(cod) == 0) {
        return 0;
        free(tmp);
    }
    strcpy(tmp, buffer + pos + 1);
    sprintf(buffer, "%s", tmp);
    free(tmp);

    return atoi(cod);
}

/**
 * Encaminha mensagem recebida de cli, para o cliente especificado no inicio da
 * mensagem
 * @param mensagem Mensagem contendo o ID do cliente que deverá receber
 * a mensagem e a própria mensagem. "Ex.: 73:Olá cliente 73"
 * @param cli
 * @return 
 */
bool encaminhaMensagem(char *mensagem, cliente *cli) {
    if (CLIENTES == NULL) return false;
    int id;
    cliente * enviar;
    char *msg = malloc(1024);
    if (mensagem == NULL) {
        return false;
    }
    id = extraiCodigo(mensagem);
    if (id == 0) return false;

    enviar = procuraCliente(id);
    if (enviar == NULL) {
        free(msg);
        return false;
    }
    sprintf(msg, "%s:%s", cli->nome, mensagem);
    if (send(enviar->socket, msg, strlen(msg), 0) <= 0) {
        free(msg);
        return false;
    }
    free(msg);

    return true;
}

/**
 * Envia mensagem para todos os clientes conectados, menos para quem está 
 * enviando
 * @param cli
 * @param msg
 * @return 
 */
bool enviaBroadcast(cliente *cli, char *msg) {
    if (CLIENTES == NULL) return true;
    cliente * enviar;
    enviar = CLIENTES->head; //pega o inicio da lista
    while (enviar != NULL) {//envia até a lista acabar

        if (enviar != cli) send(enviar->socket, msg, strlen(msg), 0);
        enviar = enviar->prox;
    }
    return true;
}

/**
 * Envia lista de clientes conectados para o cliente que está solicitando.
 * @param cli O cliente que está solicitando a mensagem.
 */
void enviaListaClientes(cliente *cli) {
    if (CLIENTES == NULL) return;
    char *msg = malloc(1024);
    cliente * tmp = CLIENTES->head;
    printf("\n\tEnviando CLIENTES");
    while (tmp != NULL) {
        switch (tmp->status) {
            case CLI_ONLINE:
                sprintf(msg, "%d:%s:ON-LINE\n\0", tmp->id, tmp->nome);
                break;
            case CLI_OCUPADO:
                sprintf(msg, "%d:%s:OCUPADO\n\0", tmp->id, tmp->nome);
                break;
        }
        send(cli->socket, msg, strlen(msg), 0);
        tmp = tmp->prox;
    }
    free(msg);
}