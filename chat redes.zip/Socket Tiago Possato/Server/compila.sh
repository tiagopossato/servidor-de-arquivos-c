#!/bin/bash

gcc -c clientes.c -o clientes.o

gcc -c processador.c -o processador.o

gcc main.c clientes.o processador.o -I/ -o server -lpthread
chmod +x server

touch executar[em_terminal].sh
chmod +x executar[em_terminal].sh

echo ./server >> executar[em_terminal].sh
rm *.o
